# Project Pumpkin Big Build

A Phaser 3 starter game for the Jack-O-Apple Halloween game.

## How to play

Open `index.html` in a browser, or publish the project with GitHub Pages.

Use the arrow keys to move the Jack-O-Apple.

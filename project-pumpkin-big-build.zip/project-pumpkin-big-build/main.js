const config = {
  type: Phaser.AUTO,
  width: 800,
  height: 600,
  parent: "game",
  backgroundColor: "#1d1d1d",
  scene: {
    preload: preload,
    create: create,
    update: update
  }
};

const game = new Phaser.Game(config);

let player;
let cursors;

function preload() {
  // Game assets will be added here later.
}

function create() {
  this.add.text(95, 60, "PROJECT PUMPKIN BIG BUILD", {
    fontSize: "34px",
    color: "#ff9933",
    fontStyle: "bold"
  });

  this.add.text(190, 110, "Jack-O-Apple Begins!", {
    fontSize: "28px",
    color: "#ffffff"
  });

  this.add.text(165, 520, "Use arrow keys to move the Jack-O-Apple", {
    fontSize: "22px",
    color: "#ffcc66"
  });

  // Simple Jack-O-Apple placeholder player
  player = this.add.circle(400, 300, 35, 0xff8c00);
  player.setStrokeStyle(4, 0x000000);

  // Face
  this.add.triangle(385, 292, 0, 12, 10, 0, 20, 12, 0x000000);
  this.add.triangle(415, 292, 0, 12, 10, 0, 20, 12, 0x000000);
  this.add.arc(400, 315, 18, 10, 170, false, 0x000000);

  cursors = this.input.keyboard.createCursorKeys();
}

function update() {
  const speed = 4;

  if (cursors.left.isDown) {
    player.x -= speed;
  } else if (cursors.right.isDown) {
    player.x += speed;
  }

  if (cursors.up.isDown) {
    player.y -= speed;
  } else if (cursors.down.isDown) {
    player.y += speed;
  }

  player.x = Phaser.Math.Clamp(player.x, 35, 765);
  player.y = Phaser.Math.Clamp(player.y, 35, 565);
}

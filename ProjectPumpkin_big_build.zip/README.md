# Project Pumpkin — Big Build

Game title: **Jack-O-Apple: It's a Halloween SMASH!**

This build includes:
- 1995 Spooky Floppy Disk boot screen
- CRT / NES-inspired screen styling
- Animated lightning
- Smasher intro
- Trailer #13 hub
- Broken Camaro + apple tree
- Convenience store: candy corn, flashlight, chocolate coins, woods warning sign
- Video store: secret Green Apple Popping Candy, Chocolate Drop, horror VHS atmosphere
- Graveyard + The Raker
- Weathered missing poster
- Haunted house with flashlight logic and danger path
- Woods sign + hearse inventory-loss encounter
- Bully encounter; candy corn protects your inventory
- Backtracking hub navigation
- Simple save/load/reset using browser localStorage
- Guided Jack-O-Apple assembly finale
- Final chant: "Jack-O-Apple! Apple, candy, chocolate... SMASH IT!"

## How to test
Open `index.html` in a browser.

## How to put on GitHub
Upload all unzipped files to your repository, not the ZIP itself.

## GitHub Pages
Settings → Pages → Deploy from branch → main → root.

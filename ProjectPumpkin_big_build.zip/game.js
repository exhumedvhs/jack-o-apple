
const SAVE_KEY = "projectPumpkinBigBuildSave";

const state = {
  inventory: [],
  flags: {},
  scene: "boot1",
  minutes: 664, // 11:04 PM
  checkpoint: null
};

function has(item){ return state.inventory.includes(item); }
function addItem(item){ if(!has(item)) state.inventory.push(item); }
function removeAllInventory(){ state.inventory = []; }
function setFlag(flag){ state.flags[flag] = true; }
function flag(flag){ return !!state.flags[flag]; }
function timeString(){
  let m = state.minutes % (24*60);
  let h = Math.floor(m/60);
  let min = String(m%60).padStart(2,"0");
  let ap = h >= 12 ? "PM":"AM";
  let hh = h%12 || 12;
  return `${hh}:${min} ${ap}`;
}
function advance(n){ state.minutes += n; }
function canAssemble(){
  return ["Apple","Orange Chocolate Coating","Chocolate Coins","Chocolate Drop","Green Apple Popping Candy"].every(has);
}
const scenes = {
  boot1: {
    art:"boot", meta:"A:\\>", title:"1995 SPOOKY FLOPPY DISK",
    text:"INITIALIZING...\n\nREADING DISK...\n████████████\n\nJACKOAPP.EXE",
    choices:[["LOAD GAME", "title"]]
  },
  title: {
    art:"title", meta:"October 31, 1995", title:"JACK-O-APPLE",
    text:"IT'S A HALLOWEEN SMASH!\n\nThunder rolls over Spooky Trailer Park. For one flash, you see Trailer #13. For another, the dead Camaro in the yard.\n\nThen the dark comes back.",
    choices:[["PRESS START", "intro1"]]
  },
  intro1: {
    art:"title", meta:"Spooky Trailer Park", title:"THE STORM",
    text:"Some places are different on Halloween.\n\nSome keep their porch lights on.\nSome shut every curtain.\nAnd some wait for kids to wander too far from home.",
    choices:[["CONTINUE", "intro2"]]
  },
  intro2: {
    art:"trailer", meta:"Trailer #13", title:"SMASHER",
    text:"Yo! Smasher here.\n\nHalloween's almost over. Your candy haul was weak, and your mom said you're NOT allowed to smash pumpkins this year.\n\nForget pumpkins.\n\nTonight, you're making something better.",
    choices:[["WHAT IS IT?", "intro3"]]
  },
  intro3: {
    art:"trailer", meta:"Trailer #13", title:"THE JACK-O-APPLE",
    text:"Apple. Candy. Chocolate.\n\nIt's a Halloween SMASH.\n\nOnly problem? The supplies are scattered around Spooky Trailer Park... and something out there doesn't want you finding them.",
    choices:[["STEP OUTSIDE", "trailer13"]]
  },
  trailer13: {
    art:"trailer", meta:"Trailer #13", title:"OUTSIDE",
    onEnter:()=>{ if(!flag("checkpoint1")) { state.checkpoint = JSON.stringify(state); setFlag("checkpoint1"); } },
    text:()=>`Rain ticks against the trailer roof. Behind the yard sits Smasher's broken-down Camaro. An apple tree has grown right through the back of it.\n\nSmasher points down the road.\n\n'Pick your next stop.'${canAssemble() ? "\n\nYou have enough to begin the Jack-O-Apple." : ""}`,
    choices:()=>[
      ["GO TO THE BACKYARD", "backyard"],
      ["GO TO THE CONVENIENCE STORE", "store"],
      ["GO TO THE VIDEO STORE", "video"],
      ["WALK TOWARD THE GRAVEYARD", "cemetery"],
      ["APPROACH THE HAUNTED HOUSE", "houseYard"],
      ["TAKE THE ROAD TOWARD THE WOODS", "woodsSign"],
      ...(canAssemble() ? [["ASSEMBLE THE JACK-O-APPLE", "assemble1"]] : [])
    ]
  },
  backyard: {
    art:"trailer", meta:"Smasher's Backyard", title:"THE CAMARO",
    text:()=> has("Apple") ?
      "The apple tree creaks in the wind. The best apple is already in your bag.\n\nThe dead Camaro sits under the branches like it gave up years ago." :
      "The Camaro is sunk into the mud behind Trailer #13. An apple tree has grown through the back, its branches scraping the ruined roof.\n\nA perfect apple hangs low in the lightning.",
    choices:()=> has("Apple") ? [["GO BACK", "trailer13"]] : [["TAKE THE APPLE", "takeApple"], ["LEAVE IT FOR NOW", "trailer13"]]
  },
  takeApple: {
    art:"trailer", meta:"ITEM FOUND", title:"APPLE",
    onEnter:()=>addItem("Apple"),
    text:"You twist the apple from the branch.\n\nSmasher grins.\n\n'That one's got history. First ingredient down.'",
    choices:[["GO BACK", "trailer13"]]
  },
  store: {
    art:"store", meta:"Spooky Convenience Store", title:"LAST STOP",
    text:"The door buzzes open. Fluorescent lights hum. The candy shelves look murdered.\n\nThe clerk glares from behind the counter.\n\n'Kid... we've been trick-or-treated to death.'\n\nHe slides over a handful of candy corn.\n\n'Only thing nobody wanted.'",
    choices:()=>[
      ...(has("Crappy Candy Corn") ? [] : [["TAKE THE CANDY CORN", "takeCandyCorn"], ["LEAVE IT", "leaveCandyCorn"]]),
      ...(has("Flashlight") ? [] : [["BUY THE FLASHLIGHT", "flashlight"]]),
      ...(has("Chocolate Coins") ? [] : [["ASK ABOUT CHOCOLATE COINS", "coins"]]),
      ["READ THE WOODS SIGN OUTSIDE", "woodsWarningPoster"],
      ["GO BACK OUTSIDE", "trailer13"]
    ]
  },
  takeCandyCorn: {
    art:"store", meta:"ITEM FOUND", title:"CANDY CORN",
    onEnter:()=>addItem("Crappy Candy Corn"),
    text:"You take the candy corn. It feels useless.\n\nSmasher nods.\n\n'Never know what garbage might save your neck.'",
    choices:[["KEEP LOOKING", "store"]]
  },
  leaveCandyCorn: {
    art:"store", meta:"BAD CANDY", title:"LEFT BEHIND",
    text:"You leave the candy corn on the counter.\n\nThe clerk shrugs.\n\n'Smart kid. Or dumb kid. Time'll tell.'",
    choices:[["KEEP LOOKING", "store"]]
  },
  flashlight: {
    art:"store", meta:"ITEM FOUND", title:"FLASHLIGHT",
    onEnter:()=>addItem("Flashlight"),
    text:"A cracked plastic flashlight hangs beside the register.\n\nThe clerk taps it once.\n\n'Power's been twitchy all night. Take it before somebody else gets brave.'",
    choices:[["KEEP LOOKING", "store"]]
  },
  coins: {
    art:"store", meta:"ITEM FOUND", title:"CHOCOLATE COINS",
    onEnter:()=>addItem("Chocolate Coins"),
    text:"The clerk reaches under the counter and drops two foil-wrapped chocolate coins into your bag.\n\n'Last two. Don't ask me why I had them under here.'",
    choices:[["KEEP LOOKING", "store"]]
  },
  woodsWarningPoster: {
    art:"store", meta:"Outside Last Stop", title:"BEWARE",
    text:"A crooked wooden sign leans near the payphone.\n\nBEWARE!\nSTAY OUT OF THE WOODS!\n\nSmasher reads it and looks down the road.\n\n'Nobody ever listens to that sign.'",
    choices:[["GO BACK INSIDE", "store"], ["RETURN TO TRAILER #13", "trailer13"]]
  },
  video: {
    art:"video", meta:"Spooky Video Store", title:"BE KIND, REWIND",
    text:"The video store smells like wet carpet and old plastic. Horror tapes line the walls. The clerk looks like he hasn't blinked since sunset.\n\n'Almost closing time, kid.'\n\nSomewhere in the back, a tape rewinds by itself.",
    choices:()=>[
      ["ASK ABOUT HORROR MOVIES", "videoMovies"],
      ...(has("Green Apple Popping Candy") ? [] : [["WAIT BY THE COUNTER", "poppingCandy"]]),
      ...(has("Chocolate Drop") ? [] : [["CHECK THE CANDY DISPLAY", "drop"]]),
      ["GO BACK OUTSIDE", "trailer13"]
    ]
  },
  videoMovies: {
    art:"video", meta:"VHS Wall", title:"THE SHELVES",
    text:"The tapes have names like NIGHT OF THE LAWN GNOMES and CURSE OF TRAILER #7.\n\nOne box is turned backward. Smasher reaches for it, then stops.\n\n'Not that one.'",
    choices:[["STEP AWAY FROM THE SHELVES", "video"]]
  },
  poppingCandy: {
    art:"video", meta:"ITEM FOUND", title:"POPPING CANDY",
    onEnter:()=>addItem("Green Apple Popping Candy"),
    text:"The clerk rubs his eyes.\n\n'Halloween's been nuts. Here, kid. Happy Halloween.'\n\nHe drops a packet of Green Apple Popping Candy into your bag.",
    choices:[["THANK HIM AND KEEP LOOKING", "video"]]
  },
  drop: {
    art:"video", meta:"ITEM FOUND", title:"CHOCOLATE DROP",
    onEnter:()=>addItem("Chocolate Drop"),
    text:"Beside the register sits one lonely foil-wrapped chocolate drop.\n\nThe clerk waves his hand.\n\n'Take it. If I eat one more piece of candy, I'm gonna see sounds.'",
    choices:[["KEEP LOOKING", "video"]]
  },
  cemetery: {
    art:"cemetery", meta:"Spooky Cemetery", title:"THE RAKER",
    onEnter:()=>setFlag("metRaker"),
    text:"The wind drags leaves across the stones.\n\nA bent old man stands between the graves, slowly raking.\n\nScrape.\n\nScrape.\n\nHe does not look up.",
    choices:[["SPEAK TO HIM", "raker"], ["CHECK THE FENCE", "missingPoster2"], ["GO BACK", "trailer13"]]
  },
  raker: {
    art:"cemetery", meta:"The Raker", title:"...",
    text:"The old man keeps raking.\n\nAfter a long while, he whispers:\n\n'Leaves keep falling.'\n\nSmasher says nothing.",
    choices:[["GO BACK", "cemetery"]]
  },
  missingPoster2: {
    art:"cemetery", meta:"Weathered Poster", title:"MISSING",
    text:"A poster is curled around the cemetery fence.\n\nMISSING\nLAST SEEN: HALLOWEEN NIGHT\n\nThe bottom half has rotted away.\n\nFor a moment, even the rain seems quieter.",
    choices:[["GO BACK", "cemetery"]]
  },
  houseYard: {
    art:"house", meta:"The House on the Hill", title:"HAUNTED HOUSE",
    text:()=>`The house waits at the edge of the park. No porch light. No pumpkins. Just a front door hanging open.\n\nSmasher whispers:\n\n'Some doors should stay closed.'${has("Flashlight") ? "\n\nYour flashlight feels heavy in your hand." : "\n\nIt is too dark inside."}`,
    choices:()=> has("Flashlight") ? [["ENTER WITH THE FLASHLIGHT", "houseFoyer"], ["TURN BACK", "trailer13"]] : [["STEP INSIDE ANYWAY", "houseNoLight"], ["TURN BACK", "trailer13"]]
  },
  houseNoLight: {
    art:"house", meta:"Too Dark", title:"THE WRONG STEP",
    text:"You step inside.\n\nThe floor disappears beneath your foot.\n\nFor one second, Smasher shouts your name.\n\nThen the house swallows every sound.",
    choices:[["RESTART FROM TRAILER #13", "trailer13"]]
  },
  houseFoyer: {
    art:"house", meta:"Inside the House", title:"FOYER",
    text:"Your flashlight beam shakes across peeling wallpaper. Something upstairs knocks once.\n\nSmasher's voice is low.\n\n'We are not here to be heroes.'",
    choices:[["SEARCH THE FRONT ROOM", "orangeChocolate"], ["GO DEEPER", "tooDeep"], ["LEAVE NOW", "trailer13"]]
  },
  orangeChocolate: {
    art:"house", meta:"ITEM FOUND", title:"ORANGE CHOCOLATE",
    onEnter:()=>addItem("Orange Chocolate Coating"),
    text:"On a dusty table sits a sealed orange chocolate bar, wrapped in plain foil.\n\nNobody asks why it's here.\n\nNobody wants the answer.",
    choices:[["LEAVE THE HOUSE", "trailer13"], ["GO DEEPER", "tooDeep"]]
  },
  tooDeep: {
    art:"house", meta:"Too Far In", title:"DISAPPEARED",
    text:"You follow the hallway past where the flashlight reaches.\n\nThe walls breathe.\n\nThe door behind you is gone.\n\nSome people were never seen again.",
    choices:[["LOAD LAST CHECKPOINT", "checkpoint"]]
  },
  woodsSign: {
    art:"woods", meta:"Road to the Woods", title:"THE SIGN",
    text:"Fog knots between the trees.\n\nA crooked wooden sign says:\n\nBEWARE!\nSTAY OUT OF THE WOODS!\n\nSomewhere far off, an engine turns over.",
    choices:[["STAY ON THE LIT ROAD", "trailer13"], ["TAKE THE SHORTCUT", "hearse"]]
  },
  hearse: {
    art:"woods", meta:"The Woods", title:"THE HEARSE",
    onEnter:()=>{ removeAllInventory(); setFlag("hearseSeen"); },
    text:"Headlights appear in the fog.\n\nAn old hearse rolls by without a driver.\n\nYou don't remember dropping your bag.\n\nYou only know it's empty when the road goes dark again.",
    choices:[["RETURN TO TRAILER #13", "trailer13"]]
  },
  bully: {
    art:"title", meta:"Roadside", title:"THE BULLY",
    text:()=> has("Crappy Candy Corn") ?
      "A bigger kid steps from behind a mailbox.\n\n'Nice bag. Hand it over.'\n\nYour fingers close around the candy corn." :
      "A bigger kid steps from behind a mailbox.\n\n'Nice bag. Hand it over.'\n\nYou reach for something to throw.\n\nYour hand finds nothing.",
    choices:()=> has("Crappy Candy Corn") ? [["THROW CANDY CORN", "bullyWin"], ["REFUSE", "bullyLose"]] : [["REFUSE", "bullyLose"]]
  },
  bullyWin: {
    art:"title", meta:"Candy Corn Works", title:"GROSS",
    text:"You throw the candy corn.\n\nThe bully catches one, stares at it, and backs away.\n\n'Candy corn? That's disgusting.'\n\nHe vanishes into the rain.",
    choices:[["KEEP MOVING", "trailer13"]]
  },
  bullyLose: {
    art:"title", meta:"Inventory Lost", title:"NICE BAG",
    onEnter:()=>removeAllInventory(),
    text:"The bully snatches your bag and dumps it into the mud.\n\nBy the time you gather yourself, every useful thing is gone.",
    choices:[["START OVER AT TRAILER #13", "trailer13"]]
  },
  assemble1: {
    art:"assembly", meta:"Trailer #13 Kitchen", title:"ASSEMBLY",
    text:"The storm reaches its peak.\n\nInside Trailer #13, Smasher clears the counter.\n\n'You actually did it.'\n\nNow make the Jack-O-Apple.",
    choices:[["CORE THE APPLE", "assemble2"]]
  },
  assemble2: { art:"assembly", meta:"Step 1", title:"CORE", text:"You core the apple clean through.", choices:[["PLUG ONE END WITH A CHOCOLATE COIN", "assemble3"]] },
  assemble3: { art:"assembly", meta:"Step 2", title:"PLUG", text:"You plug one end with a chocolate coin.", choices:[["SEAL THAT END WITH MELTED CHOCOLATE", "assemble4"]] },
  assemble4: { art:"assembly", meta:"Step 3", title:"SEAL", text:"Warm chocolate seals the bottom.", choices:[["CHILL FOR FIVE MINUTES", "assemble5"]] },
  assemble5: { art:"assembly", meta:"Step 4", title:"CHILL", text:"The fridge hums. The clock crawls. Five minutes pass.", onEnter:()=>advance(5), choices:[["FLIP THE APPLE OVER", "assemble6"]] },
  assemble6: { art:"assembly", meta:"Step 5", title:"POP ROCKS", text:"You coat the inside with Green Apple Popping Candy. It crackles in the hollow.", choices:[["FILL WITH CHOCOLATE CANDY PIECES", "assemble7"]] },
  assemble7: { art:"assembly", meta:"Step 6", title:"FILL", text:"The candy pieces pour into the apple like Halloween gravel.", choices:[["PLUG THE TOP WITH ANOTHER CHOCOLATE COIN", "assemble8"]] },
  assemble8: { art:"assembly", meta:"Step 7", title:"TOP PLUG", text:"The second chocolate coin locks the candy inside.", choices:[["PLACE THE CHOCOLATE DROP ON TOP", "assemble9"]] },
  assemble9: { art:"assembly", meta:"Step 8", title:"CHOCOLATE DROP", text:"You dip the base in warm melted chocolate and set it on top.", choices:[["COAT THE APPLE IN ORANGE CHOCOLATE", "assemble10"]] },
  assemble10: { art:"assembly", meta:"Step 9", title:"ORANGE SHELL", text:"Orange chocolate rolls over the apple until it glows like a jack-o'-lantern.", choices:[["CHILL, REMOVE, AND DECORATE", "assemble11"]] },
  assemble11: { art:"assembly", meta:"Final Step", title:"DECORATE", text:"Black icing makes the face.\n\nThe Jack-O-Apple stares back from the counter.", choices:[["SMASH IT", "smash"]] },
  smash: {
    art:"assembly", meta:"FINAL", title:"SMASH IT!",
    text:"Smasher lifts the Jack-O-Apple.\n\n'Jack-O-Apple! Apple, candy, chocolate... SMASH IT!'\n\nThe shell explodes. Candy scatters across the floor. Thunder answers from outside.\n\nHalloween is saved.",
    choices:[["PLAY AGAIN", "reset"], ["RETURN TO TITLE", "title"]]
  },
  checkpoint: {
    art:"title", meta:"Loading...", title:"CHECKPOINT",
    text:"The floppy grinds.\n\nReturning to the last safe place...",
    choices:[["CONTINUE", "trailer13"]]
  },
  reset: {
    art:"boot", meta:"RESET", title:"RESETTING",
    onEnter:()=>{ localStorage.removeItem(SAVE_KEY); location.reload(); },
    text:"Resetting...",
    choices:[]
  }
};

function maybeBully(next){
  if(!flag("bullyAppeared") && state.minutes >= 690 && !["bully","bullyWin","bullyLose"].includes(next)){
    setFlag("bullyAppeared");
    return "bully";
  }
  return next;
}

function render(id){
  if(id === "checkpoint" && state.checkpoint){
    const saved = JSON.parse(state.checkpoint);
    state.inventory = saved.inventory || [];
    state.flags = saved.flags || {};
    state.minutes = saved.minutes || 664;
    id = saved.scene || "trailer13";
  }
  const s = scenes[id];
  if(!s) return;
  state.scene = id;
  if(!["boot1","title","intro1","intro2","intro3","checkpoint"].includes(id)) advance(2);
  if(s.onEnter) s.onEnter();
  const art = document.getElementById("scene-art");
  art.className = s.art || "";
  document.getElementById("art-label").textContent = (s.art || "").toUpperCase();
  document.getElementById("meta").textContent = s.meta || "";
  document.getElementById("clock").textContent = timeString();
  document.getElementById("title").textContent = s.title || "";
  document.getElementById("text").textContent = typeof s.text === "function" ? s.text() : s.text || "";
  document.getElementById("inventory").textContent = state.inventory.length ? "BAG: " + state.inventory.join(" • ") : "BAG: empty";
  const choiceList = typeof s.choices === "function" ? s.choices() : (s.choices || []);
  const choices = document.getElementById("choices");
  choices.innerHTML = "";
  for(const [label,next] of choiceList){
    const btn = document.createElement("button");
    btn.textContent = "► " + label;
    btn.onclick = () => {
      const target = maybeBully(next);
      document.getElementById("game").classList.add("flash");
      setTimeout(()=>document.getElementById("game").classList.remove("flash"), 450);
      render(target);
    };
    choices.appendChild(btn);
  }
}
function save(){
  localStorage.setItem(SAVE_KEY, JSON.stringify(state));
  alert("Saved to spooky floppy.");
}
function load(){
  const raw = localStorage.getItem(SAVE_KEY);
  if(!raw){ alert("No save found."); return; }
  const saved = JSON.parse(raw);
  Object.assign(state, saved);
  render(state.scene || "title");
}
function reset(){
  if(confirm("Reset Project Pumpkin save?")){
    localStorage.removeItem(SAVE_KEY);
    location.reload();
  }
}
document.getElementById("saveBtn").onclick = save;
document.getElementById("loadBtn").onclick = load;
document.getElementById("resetBtn").onclick = reset;
render("boot1");
